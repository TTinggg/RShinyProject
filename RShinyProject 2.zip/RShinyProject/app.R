library(shiny)

shinyApp(ui,server)