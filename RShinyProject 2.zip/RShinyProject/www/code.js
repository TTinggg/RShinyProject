$( document ).ready(function() {
  $( ".navbar .container-fluid" ).append( '<a href="https://007.com" </a><img src="007Logo.png" align="right" width="100" height="50"> ');
});
